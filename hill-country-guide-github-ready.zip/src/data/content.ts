export const RESORT = {
  name: "Hyatt Regency Hill Country Resort and Villas",
  short: "Hill Country Resort",
  address: "9800 Hyatt Resort Drive, San Antonio, TX 78251",
  phone: "+12106471234",
  phoneLabel: "(210) 647-1234",
  base: "https://www.hyatt.com/hyatt-regency/en-US/sanhc-hyatt-regency-hill-country-resort-and-villas",
};

export const OFFICIAL = {
  home: RESORT.base,
  dining: `${RESORT.base}/dining`,
  spa: `${RESORT.base}/spa`,
  golf: `${RESORT.base}/golf`,
  activities: `${RESORT.base}/events-and-attractions`,
  faq: `${RESORT.base}/faqs`,
  experiences: "https://www.hyattexperiences.com/hyatt-regency/sanhc",
};

export const tel = (n: string) => `tel:${n}`;
export const fmtPhone = (n: string) => {
  const d = n.replace(/\D/g, "").slice(-10);
  return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
};
export const img = (f: string) => `${import.meta.env.BASE_URL}img/${f}`;

export type DiningCategory = "dinner" | "casual" | "bars" | "poolside" | "in-room";

export type Venue = {
  id: string;
  name: string;
  kicker: string;
  blurb: string;
  categories: DiningCategory[];
  hours: { label: string; value: string }[];
  dress?: string;
  where?: string;
  menu: string;
  reserve?: string;
  order?: string;
  phone?: string;
};

export const DINING_FILTERS: { id: "all" | DiningCategory; label: string }[] = [
  { id: "all", label: "Everything" },
  { id: "dinner", label: "Dinner" },
  { id: "casual", label: "Casual bites" },
  { id: "bars", label: "Bars & lounges" },
  { id: "poolside", label: "Poolside" },
  { id: "in-room", label: "In-room" },
];

export const VENUES: Venue[] = [
  {
    id: "antlers",
    name: "Antlers Lodge",
    kicker: "Upscale Texas steakhouse",
    blurb: "The resort's signature dinner room. Settle in for a proper Texas steakhouse evening.",
    categories: ["dinner"],
    hours: [{ label: "Daily", value: "5:30 – 9:30 pm" }],
    dress: "Resort casual",
    menu: "https://l.ead.me/bc7Yfw",
    reserve: "https://antlerslodge.getbento.com/reservations/",
    phone: "+12105204001",
  },
  {
    id: "springhouse",
    name: "Springhouse Cafe",
    kicker: "All-day casual dining",
    blurb: "Breakfast, lunch and dinner in an easygoing room. Where most mornings begin.",
    categories: ["casual", "dinner"],
    hours: [
      { label: "Breakfast", value: "7 – 11:30 am" },
      { label: "Lunch", value: "11:30 am – 1:30 pm" },
      { label: "Dinner", value: "5:30 – 9:30 pm" },
    ],
    dress: "Casual",
    menu: "https://l.ead.me/bcG8I9",
    phone: "+12105204000",
  },
  {
    id: "charlies",
    name: "Charlie's Long Bar",
    kicker: "Drinks, billiards & shuffleboard",
    blurb: "A long bar with a game room attitude. Rack up, slide a puck, order another round.",
    categories: ["bars"],
    hours: [
      { label: "Mon – Fri", value: "4 pm – midnight" },
      { label: "Sat – Sun", value: "noon – midnight" },
      { label: "Food", value: "until 10 pm" },
    ],
    menu: "https://l.ead.me/bfjZL4",
  },
  {
    id: "woodbine",
    name: "Woodbine Bar",
    kicker: "Lobby cocktails & tapas",
    blurb: "Small plates and a well-made drink in the lobby, any afternoon you need one.",
    categories: ["bars"],
    hours: [{ label: "Daily", value: "2 – 9 pm" }],
    where: "Lobby",
    menu: "https://l.ead.me/bfJ4F2",
  },
  {
    id: "cactus-oak",
    name: "Cactus Oak Tavern",
    kicker: "Golfer's tavern",
    blurb: "A quick bite before the front nine or a cold one after the back.",
    categories: ["casual", "bars"],
    hours: [{ label: "Daily", value: "10 am – 5 pm" }],
    where: "Opposite the Golf Pro Shop",
    menu: "https://l.ead.me/bciN1j",
  },
  {
    id: "aunt-dis",
    name: "Aunt Di's Comfort Station",
    kicker: "Sandwiches, salads & cocktails",
    blurb: "Sand-between-the-toes dining right at the lagoon.",
    categories: ["poolside", "casual"],
    hours: [
      { label: "Sun – Thu", value: "11 am – 5 pm" },
      { label: "Fri – Sat", value: "11 am – 7 pm" },
    ],
    where: "Big Spring Lagoon",
    menu: "https://l.ead.me/bg1F7R",
  },
  {
    id: "papa-eds",
    name: "Papa Ed's Pool Bar and Grill",
    kicker: "Pool bar & grill",
    blurb: "Grill fare and cold drinks without leaving the pool deck.",
    categories: ["poolside"],
    hours: [
      { label: "Sun – Thu", value: "11 am – 5 pm" },
      { label: "Fri – Sat", value: "11 am – 6 pm" },
    ],
    menu: "https://l.ead.me/bbznMr",
  },
  {
    id: "vinces",
    name: "Vince's Watering Hole",
    kicker: "In the water park",
    blurb: "Refreshment stop inside the water park.",
    categories: ["poolside"],
    hours: [{ label: "Hours", value: "Contact the hotel" }],
    where: "Water park",
    menu: "https://l.ead.me/bc3408",
  },
  {
    id: "in-room",
    name: "Express In-Room Dining",
    kicker: "Delivered to your door",
    blurb: "Breakfast in a robe. Late supper without shoes. Order online.",
    categories: ["in-room"],
    hours: [
      { label: "Breakfast", value: "7 – 11 am" },
      { label: "All-day", value: "11:30 am – 10 pm" },
    ],
    menu: "https://l.ead.me/bfnkBK",
    order: "https://l.ead.me/bbcl3r",
  },
];

export type MapGroup = "dining" | "recreation" | "wellness" | "golf" | "essentials";

export type Place = { id: string; name: string; group: MapGroup; note: string };

export const MAP_GROUPS: { id: "all" | MapGroup; label: string }[] = [
  { id: "all", label: "All" },
  { id: "dining", label: "Dining" },
  { id: "recreation", label: "Water & play" },
  { id: "golf", label: "Golf" },
  { id: "wellness", label: "Spa & fitness" },
  { id: "essentials", label: "Essentials" },
];

export const PLACES: Place[] = [
  { id: "resort", name: "Resort Lobby", group: "essentials", note: "Main entrance and front desk" },
  { id: "woodbine", name: "Woodbine Bar", group: "dining", note: "Lobby cocktails and tapas" },
  { id: "antlers", name: "Antlers Lodge", group: "dining", note: "Texas steakhouse" },
  { id: "springhouse", name: "Springhouse Cafe", group: "dining", note: "Breakfast, lunch, dinner" },
  { id: "charlies", name: "Charlie's Long Bar", group: "dining", note: "Billiards and shuffleboard" },
  { id: "cactus-oak", name: "Cactus Oak Tavern", group: "dining", note: "Opposite the Golf Pro Shop" },
  { id: "aunt-dis", name: "Aunt Di's Comfort Station", group: "dining", note: "At Big Spring Lagoon" },
  { id: "papa-eds", name: "Papa Ed's Pool Bar and Grill", group: "dining", note: "Pool bar and grill" },
  { id: "water-park", name: "Water Park and Lazy River", group: "recreation", note: "Lazy river, pools, waterslide" },
  { id: "flowrider", name: "FlowRider", group: "recreation", note: "Additional fee, reserve at kiosk" },
  { id: "lagoon", name: "Big Spring Lagoon", group: "recreation", note: "2.2-acre beach lagoon" },
  { id: "golf", name: "Hill Country Golf Club", group: "golf", note: "27 holes, pro shop" },
  { id: "toptracer", name: "Toptracer Golf Bays", group: "golf", note: "Groups up to six" },
  { id: "spa", name: "Windflower Spa", group: "wellness", note: "Massage, facials, nails" },
  { id: "fitness", name: "Fitness Center", group: "wellness", note: "Open 24 hours" },
];

export const placeQuery = (p: Place) =>
  p.id === "resort" ? `${RESORT.name}, ${RESORT.address}` : `${p.name}, ${RESORT.name}, ${RESORT.address}`;
export const embedUrl = (q: string) => `https://maps.google.com/maps?q=${encodeURIComponent(q)}&z=16&output=embed`;
export const directionsUrl = (q: string) =>
  `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(q)}`;

export const GOLF = {
  site: "https://www.hyatthillcountrygolf.com/",
  teeTimes: "https://hyatt-hill-country-resort.book.teeitup.com/?course=475",
  course: "https://www.hyatthillcountrygolf.com/course/",
  lessons: "https://www.hyatthillcountrygolf.com/golf-lessons/",
  rentals: "https://www.hyatthillcountrygolf.com/rental-clubs/",
  shopPhone: "+12105204040",
};

export const SPA = {
  phone: "+12107675577",
  book: "https://na.spatime.com/hrh78251/63832736/home",
  massageMenu: "https://na.spatime.com/hrh78251/63832736/offering/63833009",
  duet: "https://na.spatime.com/hrh78251/63832736/spa-service/service-item/63833169",
  massages: [
    { name: "Relaxation", line: "Unhurried, soothing pressure for letting the week go." },
    { name: "Wildflower", line: "A Hill Country–inspired signature drawing on native botanicals." },
    { name: "Therapeutic", line: "Focused work for tight shoulders, long drives and golf backs." },
  ],
  amenities: [
    "Indoor hot tub",
    "Sauna",
    "Eucalyptus steam room",
    "Private heated outdoor pool",
    "Relaxation porch",
  ],
};

export type Activity = { id: string; name: string; line: string; tag: string; note?: string };

export const WATER: Activity[] = [
  { id: "lazy-river", name: "Lazy river", line: "Float the long way around.", tag: "Water park" },
  { id: "activity-pool", name: "Activity pool", line: "Room to splash for every age.", tag: "Water park" },
  { id: "texas-pool", name: "Adults-only Texas pool", line: "A quieter pool for grown-ups.", tag: "Adults only" },
  { id: "kiddie", name: "Zero-entry kiddie pool", line: "Walk-in shallows for little ones.", tag: "Families" },
  { id: "slide", name: "Two-story waterslide", line: "The fastest way down.", tag: "Water park" },
  { id: "flowrider", name: "FlowRider", line: "Surf simulator. Additional fee; reserve at the kiosk or with the hotel.", tag: "Reservation" },
  { id: "lagoon", name: "Big Spring Lagoon", line: "A 2.2-acre beach lagoon open to resort guests.", tag: "Resort guests" },
];

export const OUTDOORS: Activity[] = [
  { id: "trails", name: "Biking & walking trails", line: "Stretch your legs across the grounds.", tag: "Outdoors" },
  { id: "courts", name: "Tennis & pickleball", line: "Courts for a friendly match.", tag: "Courts" },
  { id: "smores", name: "Evening s'mores", line: "Fireside, marshmallows, slow evenings.", tag: "Evenings" },
  { id: "movies", name: "Family movies", line: "Screenings for the whole crew.", tag: "Families" },
  { id: "wildlife", name: "Wildlife feedings", line: "Meet some of the resort's residents.", tag: "Families" },
  { id: "acoustic", name: "Acoustic Evenings at Woodbine", line: "Live acoustic music, 5:30 – 8:30 pm on select dates only.", tag: "Select dates" },
  { id: "goat-yoga", name: "Goat Yoga", line: "A Saturday offering, subject to the current schedule.", tag: "Saturdays" },
  { id: "fitness", name: "Fitness center", line: "Open 24 hours.", tag: "24 hours" },
];

export const GUEST_INFO = [
  { label: "Resort main line", value: RESORT.phoneLabel, href: tel(RESORT.phone) },
  { label: "Windflower Spa", value: fmtPhone(SPA.phone), href: tel(SPA.phone) },
  { label: "Golf shop", value: fmtPhone(GOLF.shopPhone), href: tel(GOLF.shopPhone) },
  { label: "Springhouse Cafe", value: "(210) 520-4000", href: tel("+12105204000") },
  { label: "Antlers Lodge", value: "(210) 520-4001", href: tel("+12105204001") },
];

export type Hotspot = {
  id: string;
  num?: string;
  name: string;
  mapLabel?: string;
  group: MapGroup;
  x: number; // % of cropped map width
  y: number; // % of cropped map height
  detail: string;
  venueId?: string;
  guide: { href: string; label: string };
};

export const HOTSPOTS: Hotspot[] = [
  { id: "springhouse", num: "1", name: "Springhouse Cafe", group: "dining", x: 58.9, y: 63.6, detail: "Breakfast, lunch and dinner. Casual.", venueId: "springhouse", guide: { href: "/dining", label: "Dining guide" } },
  { id: "antlers", num: "2", name: "Antlers Lodge", group: "dining", x: 34.4, y: 54.9, detail: "Upscale Texas steakhouse, daily 5:30 – 9:30 pm.", venueId: "antlers", guide: { href: "/dining", label: "Dining guide" } },
  { id: "charlies", num: "3", name: "Charlie's Long Bar", group: "dining", x: 53.0, y: 58.7, detail: "Drinks, billiards and shuffleboard.", venueId: "charlies", guide: { href: "/dining", label: "Dining guide" } },
  { id: "woodbine", num: "4", name: "Woodbine Bar", group: "dining", x: 63.6, y: 60.0, detail: "Lobby cocktails and tapas, 2 – 9 pm daily.", venueId: "woodbine", guide: { href: "/dining", label: "Dining guide" } },
  { id: "cactus-oak", num: "5", name: "Cactus Oak Tavern", mapLabel: "Cactus Oak \u201cTinsel Tavern\u201d", group: "dining", x: 34.3, y: 49.8, detail: "Opposite the Golf Pro Shop, 10 am – 5 pm daily.", venueId: "cactus-oak", guide: { href: "/dining", label: "Dining guide" } },
  { id: "papa-eds", num: "7", name: "Papa Ed's Pool Bar and Grill", group: "dining", x: 49.3, y: 66.0, detail: "Pool bar and grill by the pools.", venueId: "papa-eds", guide: { href: "/dining", label: "Dining guide" } },
  { id: "vinces", num: "8", name: "Vince's Watering Hole", group: "dining", x: 71.1, y: 70.9, detail: "In the water park. Hours: contact the hotel.", venueId: "vinces", guide: { href: "/dining", label: "Dining guide" } },
  { id: "activity-pool", num: "9", name: "Activity Pool", group: "recreation", x: 50.0, y: 69.8, detail: "Part of the water park.", guide: { href: "/happenings", label: "Water & play" } },
  { id: "texas-pool", num: "10", name: "Texas Pool", group: "recreation", x: 45.9, y: 68.2, detail: "Adults-only pool.", guide: { href: "/happenings", label: "Water & play" } },
  { id: "lagoon", num: "16", name: "Big Spring Lagoon", mapLabel: "Crystal Lagoon", group: "recreation", x: 17.8, y: 66.5, detail: "2.2-acre beach lagoon open to resort guests. Aunt Di's Comfort Station is here.", venueId: "aunt-dis", guide: { href: "/happenings", label: "Water & play" } },
  { id: "golf", name: "Hill Country Golf Club & Pro Shop", group: "golf", x: 32.2, y: 63.0, detail: "27 holes, practice area, PGA instruction and rentals.", guide: { href: "/golf", label: "Golf guide" } },
  { id: "spa", name: "Windflower Spa", group: "wellness", x: 85.0, y: 62.0, detail: "Massage, facials, body treatments and nails. Daily 8:30 am – 6 pm.", guide: { href: "/spa", label: "Spa guide" } },
];
