import type { ReactNode } from "react";
import { ArrowUpRight, Phone } from "lucide-react";
import { cn } from "@/lib/utils";
import { fmtPhone, tel } from "@/data/content";

export function Ext({
  href,
  children,
  className,
  variant = "ghost",
  testId,
}: {
  href: string;
  children: ReactNode;
  className?: string;
  variant?: "solid" | "outline" | "ghost" | "teal";
  testId?: string;
}) {
  const styles = {
    solid: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_6px_18px_-8px_hsl(var(--primary)/.8)]",
    teal: "bg-accent text-accent-foreground hover:bg-accent/90",
    outline: "border border-foreground/20 hover:border-foreground/50 hover:bg-card",
    ghost: "underline decoration-primary/40 underline-offset-4 hover:decoration-primary px-0",
  }[variant];
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      data-testid={testId}
      className={cn(
        "group inline-flex items-center gap-1.5 rounded-full text-sm font-medium transition-all active:scale-[.97]",
        variant !== "ghost" && "px-4 py-2.5",
        styles,
        className,
      )}
    >
      {children}
      <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
    </a>
  );
}

export function Call({ number, label, className }: { number: string; label?: string; className?: string }) {
  return (
    <a
      href={tel(number)}
      data-testid={`link-call-${number}`}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-foreground/20 px-4 py-2.5 text-sm font-medium transition-all hover:border-foreground/50 hover:bg-card active:scale-[.97]",
        className,
      )}
    >
      <Phone className="h-3.5 w-3.5" />
      {label ?? fmtPhone(number)}
    </a>
  );
}

export function PageHero({
  eyebrow,
  title,
  lede,
  image,
  alt,
}: {
  eyebrow: string;
  title: ReactNode;
  lede: string;
  image: string;
  alt: string;
}) {
  return (
    <header className="relative overflow-hidden rounded-b-[2rem] md:rounded-[2rem] md:mx-6 md:mt-4">
      <img src={image} alt={alt} className="absolute inset-0 h-full w-full object-cover scale-105 rise" />
      <div className="absolute inset-0 bg-gradient-to-t from-[hsl(200_30%_10%/.85)] via-[hsl(200_30%_10%/.35)] to-transparent" />
      <div className="relative flex min-h-[58vh] md:min-h-[440px] flex-col justify-end px-5 pb-8 pt-28 md:px-12 md:pb-12 text-[hsl(40_50%_96%)]">
        <p className="eyebrow rise text-[hsl(42_80%_70%)]">{eyebrow}</p>
        <h1 className="font-display rise mt-3 text-5xl leading-[.95] md:text-7xl" style={{ animationDelay: ".08s" }}>
          {title}
        </h1>
        <p className="rise mt-4 max-w-lg text-base/relaxed opacity-90" style={{ animationDelay: ".16s" }}>
          {lede}
        </p>
      </div>
      <Illustrative />
    </header>
  );
}

export function Illustrative({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "absolute right-3 top-20 md:top-3 rounded-full bg-black/30 px-2 py-0.5 font-mono text-[9px] uppercase tracking-widest text-white/75 backdrop-blur",
        className,
      )}
    >
      Illustrative image
    </span>
  );
}

export function SectionHead({ eyebrow, title, children }: { eyebrow: string; title: ReactNode; children?: ReactNode }) {
  return (
    <div className="mb-6">
      <p className="eyebrow text-primary">{eyebrow}</p>
      <h2 className="font-display mt-2 text-3xl md:text-4xl leading-tight">{title}</h2>
      {children && <p className="mt-2 max-w-xl text-muted-foreground">{children}</p>}
    </div>
  );
}

export function Chips<T extends string,>({
  options,
  value,
  onChange,
  testPrefix,
}: {
  options: readonly { id: NoInfer<T>; label: string }[];
  value: T;
  onChange: (v: T) => void;
  _?: never;
  testPrefix: string;
}) {
  return (
    <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 pb-1 md:mx-0 md:flex-wrap md:px-0">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          data-testid={`${testPrefix}-${o.id}`}
          className={cn(
            "shrink-0 rounded-full border px-4 py-2 text-sm transition-all active:scale-95",
            value === o.id
              ? "border-accent bg-accent text-accent-foreground"
              : "border-foreground/15 bg-card/60 hover:border-foreground/40",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function SubjectNote({ children }: { children?: ReactNode }) {
  return (
    <p className="rounded-2xl border border-dashed border-primary/40 bg-primary/5 px-4 py-3 text-sm text-foreground/80">
      {children ?? "Hours, offerings and availability subject to change. Please confirm with the resort or concierge."}
    </p>
  );
}
