import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { QRCodeSVG } from "qrcode.react";
import { Compass, Map, UtensilsCrossed, Flag, Flower2, Sun, Share2, Copy, AlertTriangle, Phone } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { OFFICIAL, RESORT, tel } from "@/data/content";

const NAV = [
  { href: "/", label: "Welcome", icon: Compass },
  { href: "/map", label: "Map", icon: Map },
  { href: "/dining", label: "Dining", icon: UtensilsCrossed },
  { href: "/golf", label: "Golf", icon: Flag },
  { href: "/spa", label: "Spa", icon: Flower2 },
  { href: "/happenings", label: "Happenings", icon: Sun },
];

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-2.5" data-testid="link-home-brand">
      <svg viewBox="0 0 40 40" className="h-8 w-8 text-primary" aria-hidden>
        <circle cx="20" cy="20" r="18.5" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <path d="M5 26 Q13 17 20 22 T35 20" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="26" cy="13" r="3.5" fill="currentColor" />
      </svg>
      <span className="leading-none">
        <span className="font-display block text-[17px]">Hill Country</span>
        <span className="eyebrow text-[9px] text-muted-foreground">Guest guide</span>
      </span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [shareOpen, setShareOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [location]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <div className="min-h-[100dvh] pb-24 md:pb-0">
      <nav
        className={cn(
          "fixed inset-x-0 top-0 z-40 transition-all duration-300",
          scrolled ? "bg-background/85 backdrop-blur-md border-b border-border" : "bg-transparent",
        )}
      >
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:px-6">
          <div className={cn("rounded-full px-3 py-1.5 transition-colors", !scrolled && "bg-background/85 backdrop-blur")}>
            <Brand />
          </div>
          <div className="hidden items-center gap-1 rounded-full bg-background/85 p-1 backdrop-blur md:flex">
            {NAV.map((n) => (
              <Link
                key={n.href}
                href={n.href}
                data-testid={`link-nav-${n.label.toLowerCase()}`}
                className={cn(
                  "rounded-full px-3.5 py-1.5 text-sm transition-colors",
                  location === n.href ? "bg-foreground text-background" : "hover:bg-muted",
                )}
              >
                {n.label}
              </Link>
            ))}
          </div>
          <button
            onClick={() => setShareOpen(true)}
            data-testid="button-share"
            className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground transition-transform active:scale-95"
          >
            <Share2 className="h-4 w-4" /> Share
          </button>
        </div>
      </nav>

      <main key={location} className="rise">
        {children}
      </main>

      <Footer />

      <nav className="fixed inset-x-3 bottom-3 z-40 md:hidden">
        <div className="grid grid-cols-6 rounded-[1.4rem] border border-border bg-card/95 p-1.5 shadow-[0_12px_30px_-12px_hsl(200_30%_14%/.45)] backdrop-blur">
          {NAV.map((n) => {
            const active = location === n.href;
            return (
              <Link
                key={n.href}
                href={n.href}
                data-testid={`tab-${n.label.toLowerCase()}`}
                className={cn(
                  "flex flex-col items-center gap-0.5 rounded-2xl py-2 text-[10px] transition-all active:scale-90",
                  active ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                )}
              >
                <n.icon className={cn("h-[18px] w-[18px] transition-transform", active && "-translate-y-px")} />
                {n.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} />
    </div>
  );
}

function Footer() {
  return (
    <footer className="mx-auto mt-20 max-w-6xl px-5 pb-10 md:px-6">
      <div className="stitch mb-8 opacity-60" />
      <div className="grid gap-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Brand />
          <p className="mt-4 max-w-sm text-sm text-muted-foreground">
            {RESORT.name}
            <br />
            {RESORT.address}
          </p>
          <a href={tel(RESORT.phone)} className="mt-3 inline-flex items-center gap-2 text-sm font-medium" data-testid="link-footer-phone">
            <Phone className="h-4 w-4 text-primary" /> {RESORT.phoneLabel}
          </a>
        </div>
        <div className="text-sm">
          <p className="eyebrow mb-3 text-primary">Official sources</p>
          <ul className="space-y-2">
            {[
              ["Resort home", OFFICIAL.home],
              ["Dining", OFFICIAL.dining],
              ["Spa", OFFICIAL.spa],
              ["Golf", OFFICIAL.golf],
              ["Events & attractions", OFFICIAL.activities],
              ["FAQs", OFFICIAL.faq],
            ].map(([l, h]) => (
              <li key={h}>
                <a href={h} target="_blank" rel="noopener noreferrer" className="hover:text-primary" data-testid={`link-source-${l}`}>
                  {l}
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div className="text-sm text-muted-foreground">
          <p className="eyebrow mb-3 text-primary">Good to know</p>
          <p>Hours, offerings and availability subject to change.</p>
          <p className="mt-3">Imagery on this guide is illustrative and does not depict the actual resort.</p>
        </div>
      </div>
      <p className="mt-10 font-mono text-[11px] tracking-wide text-muted-foreground">
        Independent guest guide. Refer to Hyatt for latest details.
      </p>
    </footer>
  );
}

function ShareDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const { toast } = useToast();
  const url = typeof window !== "undefined" ? window.location.href : "";
  const host = typeof window !== "undefined" ? window.location.hostname : "";
  const isPreview = /replit\.dev$|localhost|127\.0\.0\.1|repl\.co$/.test(host);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast({ title: "Link copied", description: "Paste it anywhere to share this page." });
    } catch {
      toast({ title: "Couldn't copy", description: "Select and copy the link manually." });
    }
  };
  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: "Hill Country Guest Guide", url });
      } catch {
        /* dismissed */
      }
    } else copy();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-3xl border-border bg-card">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Pass it along</DialogTitle>
          <DialogDescription>Scan to open this page on another phone.</DialogDescription>
        </DialogHeader>
        {isPreview && (
          <div className="flex gap-2 rounded-2xl bg-[hsl(42_80%_55%/.18)] p-3 text-sm" data-testid="text-preview-warning">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <span>
              <strong>Preview link.</strong> This is a temporary development address, not a permanent guest URL. Regenerate the QR once the guide is published.
            </span>
          </div>
        )}
        <div className="mx-auto rounded-2xl bg-[hsl(40_50%_97%)] p-4 ring-1 ring-border">
          <QRCodeSVG value={url} size={196} bgColor="#faf6ee" fgColor="#1a2a33" level="M" data-testid="img-qr" />
        </div>
        <p className="break-all rounded-xl bg-muted px-3 py-2 font-mono text-[11px]" data-testid="text-share-url">
          {url}
        </p>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={copy} data-testid="button-copy-link" className="inline-flex items-center justify-center gap-2 rounded-full border border-foreground/20 py-2.5 text-sm active:scale-95">
            <Copy className="h-4 w-4" /> Copy link
          </button>
          <button onClick={share} data-testid="button-native-share" className="inline-flex items-center justify-center gap-2 rounded-full bg-primary py-2.5 text-sm text-primary-foreground active:scale-95">
            <Share2 className="h-4 w-4" /> Share
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
