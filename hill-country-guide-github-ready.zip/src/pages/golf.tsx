import { Call, Ext, PageHero, SectionHead, SubjectNote } from "@/components/bits";
import { GOLF, OFFICIAL, img } from "@/data/content";

const FACTS = [
  ["27", "holes across three nine-hole courses"],
  ["200+", "acres of Hill Country terrain"],
  ["Arthur Hills", "course design"],
  ["Year-round", "public play"],
];

export default function Golf() {
  return (
    <>
      <PageHero
        eyebrow="Hill Country Golf Club"
        title={<>Fairways <em>& live oaks.</em></>}
        lede="Three nines, a practice area and putting green, PGA instruction and rentals if you left the bag at home."
        image={img("golf.jpg")}
        alt="Illustrative golf fairway"
      />
      <div className="mx-auto max-w-6xl px-5 pt-10 md:px-6">
        <div className="-mt-20 relative z-10 rounded-[1.75rem] bg-accent p-5 text-accent-foreground shadow-xl md:flex md:items-center md:justify-between md:p-7">
          <div>
            <p className="eyebrow text-[hsl(42_80%_70%)]">Ready to play</p>
            <p className="font-display mt-1 text-3xl">Book a tee time</p>
            <p className="mt-1 text-sm opacity-80">Live availability on the official booking site.</p>
          </div>
          <div className="mt-4 flex flex-wrap gap-2 md:mt-0">
            <Ext href={GOLF.teeTimes} variant="solid" testId="link-tee-times">Tee times</Ext>
            <Call number={GOLF.shopPhone} label="Golf shop" className="border-white/30 hover:bg-white/10" />
          </div>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-px overflow-hidden rounded-[1.75rem] bg-border md:grid-cols-4">
          {FACTS.map(([n, l]) => (
            <div key={l} className="bg-card p-5">
              <p className="font-display text-3xl text-primary md:text-4xl">{n}</p>
              <p className="mt-1 text-sm text-muted-foreground">{l}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 grid gap-8 md:grid-cols-2">
          <div>
            <SectionHead eyebrow="On the course" title="Everything for the round" />
            <ul className="divide-y divide-border border-y border-border">
              {[
                ["The course", "Layouts, hole details and course notes.", GOLF.course, "course"],
                ["Lessons", "PGA instruction for every level.", GOLF.lessons, "lessons"],
                ["Rental clubs", "Available by calling the golf shop.", GOLF.rentals, "rentals"],
                ["Golf club website", "News, policies and more.", GOLF.site, "site"],
              ].map(([t, d, h, id]) => (
                <li key={id} className="flex items-center justify-between gap-4 py-4">
                  <div>
                    <p className="font-display text-xl">{t}</p>
                    <p className="text-sm text-muted-foreground">{d}</p>
                  </div>
                  <Ext href={h} variant="outline" className="shrink-0 py-1.5 text-xs" testId={`link-golf-${id}`}>Open</Ext>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-[1.75rem] bg-secondary p-6 md:p-8">
            <p className="eyebrow text-primary">Something different</p>
            <h3 className="font-display mt-2 text-3xl">Toptracer golf bays</h3>
            <p className="mt-3 text-foreground/80">
              Ball-tracking bays for groups up to six, with Callaway clubs and unlimited balls. A good bet for mixed groups and non-golfers.
            </p>
            <p className="mt-3 text-sm text-muted-foreground">Check availability on the official golf site.</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Ext href={GOLF.site} variant="teal" testId="link-toptracer">Golf club site</Ext>
              <Ext href={OFFICIAL.golf} variant="outline" testId="link-official-golf">Hyatt golf page</Ext>
            </div>
          </div>
        </div>
        <div className="mt-10"><SubjectNote /></div>
      </div>
    </>
  );
}
