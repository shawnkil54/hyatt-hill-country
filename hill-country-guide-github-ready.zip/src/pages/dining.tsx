import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MapPin, Shirt } from "lucide-react";
import { Call, Chips, Ext, PageHero, SubjectNote } from "@/components/bits";
import { DINING_FILTERS, OFFICIAL, VENUES, img, type DiningCategory } from "@/data/content";

export default function Dining() {
  const [filter, setFilter] = useState<"all" | DiningCategory>("all");
  const list = useMemo(() => (filter === "all" ? VENUES : VENUES.filter((v) => v.categories.includes(filter))), [filter]);

  return (
    <>
      <PageHero
        eyebrow="Dining & drinks"
        title={<>Pull up <em>a chair.</em></>}
        lede="From a white-tablecloth steak to a lagoon-side sandwich. Every menu below links straight to the resort's own."
        image={img("dining.jpg")}
        alt="Illustrative steakhouse table"
      />
      <div className="mx-auto max-w-6xl px-5 pt-10 md:px-6">
        <div className="sticky top-[60px] z-30 -mx-5 bg-background/90 px-5 py-3 backdrop-blur md:mx-0 md:px-0">
          <Chips options={DINING_FILTERS} value={filter} onChange={(value: "all" | DiningCategory) => setFilter(value)} testPrefix="filter-dining" />
        </div>
        <p className="mb-4 mt-2 font-mono text-xs text-muted-foreground" data-testid="text-dining-count">
          {list.length} {list.length === 1 ? "place" : "places"}
        </p>

        <motion.div layout className="grid gap-4 md:grid-cols-2">
          <AnimatePresence mode="popLayout">
            {list.map((v, i) => (
              <motion.article
                layout
                key={v.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0, transition: { delay: i * 0.03 } }}
                exit={{ opacity: 0, scale: 0.97 }}
                className="flex flex-col rounded-[1.75rem] border border-card-border bg-card p-5 md:p-6"
                data-testid={`card-venue-${v.id}`}
              >
                <p className="eyebrow text-primary">{v.kicker}</p>
                <h3 className="font-display mt-1.5 text-3xl">{v.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{v.blurb}</p>
                <dl className="mt-4 space-y-1.5 border-t border-dashed border-border pt-4 text-sm">
                  {v.hours.map((h) => (
                    <div key={h.label} className="flex justify-between gap-4">
                      <dt className="text-muted-foreground">{h.label}</dt>
                      <dd className="font-mono text-[13px]">{h.value}</dd>
                    </div>
                  ))}
                </dl>
                {(v.where || v.dress) && (
                  <div className="mt-3 flex flex-wrap gap-2 text-xs">
                    {v.where && <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1"><MapPin className="h-3 w-3" />{v.where}</span>}
                    {v.dress && <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1"><Shirt className="h-3 w-3" />{v.dress}</span>}
                  </div>
                )}
                <div className="mt-auto flex flex-wrap gap-2 pt-5">
                  <Ext href={v.menu} variant="solid" testId={`link-menu-${v.id}`}>View menu</Ext>
                  {v.reserve && <Ext href={v.reserve} variant="teal" testId={`link-reserve-${v.id}`}>Reserve</Ext>}
                  {v.order && <Ext href={v.order} variant="teal" testId={`link-order-${v.id}`}>Order now</Ext>}
                  {v.phone && <Call number={v.phone} />}
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>

        <div className="mt-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <SubjectNote />
          <Ext href={OFFICIAL.dining} variant="outline" className="shrink-0" testId="link-official-dining">Official dining page</Ext>
        </div>
      </div>
    </>
  );
}
