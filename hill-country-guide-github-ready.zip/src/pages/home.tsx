import { Link } from "wouter";
import { ArrowRight, MapPin, Phone, Clock } from "lucide-react";
import { Ext, Illustrative, SectionHead, SubjectNote } from "@/components/bits";
import { GUEST_INFO, OFFICIAL, RESORT, VENUES, directionsUrl, img, tel } from "@/data/content";

const DOORS = [
  { href: "/map", title: "Find your way", sub: "Map & directions", image: "hero.jpg", span: "md:col-span-2" },
  { href: "/dining", title: "Eat & drink", sub: `${VENUES.length} spots, real menus`, image: "dining.jpg", span: "" },
  { href: "/golf", title: "Tee it up", sub: "27 holes, Arthur Hills", image: "golf.jpg", span: "" },
  { href: "/spa", title: "Unwind", sub: "Windflower Spa", image: "spa.jpg", span: "" },
  { href: "/happenings", title: "Get outside", sub: "River, lagoon & more", image: "water.jpg", span: "" },
];

export default function Home() {
  return (
    <>
      <section className="relative min-h-[100dvh] overflow-hidden">
        <img src={img("hero.jpg")} alt="Illustrative Hill Country landscape at golden hour" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(39_45%_93%/.0)] via-[hsl(200_30%_10%/.15)] to-[hsl(200_30%_10%/.85)]" />
        <Illustrative />
        <div className="relative mx-auto flex min-h-[100dvh] max-w-6xl flex-col justify-end px-5 pb-28 md:px-6 md:pb-16 text-[hsl(40_50%_96%)]">
          <p className="eyebrow rise text-[hsl(42_80%_72%)]">Howdy, and welcome</p>
          <h1 className="font-display rise mt-4 text-[3.4rem] leading-[.92] md:text-[7rem]" style={{ animationDelay: ".1s" }}>
            Kick off
            <br />
            <em className="text-[hsl(24_85%_70%)]">your boots.</em>
          </h1>
          <p className="rise mt-5 max-w-md text-lg/relaxed opacity-90" style={{ animationDelay: ".2s" }}>
            Your pocket concierge for {RESORT.name}. Where to eat, where to float, where to tee off, and how to get there.
          </p>
          <div className="rise mt-7 flex flex-wrap gap-3" style={{ animationDelay: ".3s" }}>
            <Link href="/map" data-testid="link-hero-map" className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 font-medium text-primary-foreground transition-transform active:scale-95">
              Open the map <ArrowRight className="h-4 w-4" />
            </Link>
            <a href={tel(RESORT.phone)} data-testid="link-hero-call" className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/10 px-5 py-3 backdrop-blur transition-transform active:scale-95">
              <Phone className="h-4 w-4" /> Call the resort
            </a>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pt-16 md:px-6">
        <SectionHead eyebrow="Pick a trail" title={<>Five ways to spend <em>the day</em></>} />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
          {DOORS.map((d, i) => (
            <Link
              key={d.href}
              href={d.href}
              data-testid={`card-door-${d.href.slice(1)}`}
              className={`group relative overflow-hidden rounded-3xl ${i === 0 ? "col-span-2 aspect-[2/1] md:aspect-auto md:row-span-2" : "aspect-[4/5]"} ${d.span}`}
            >
              <img src={img(d.image)} alt="" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(200_30%_10%/.8)] to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 text-[hsl(40_50%_96%)]">
                <p className="font-display text-2xl md:text-3xl">{d.title}</p>
                <p className="mt-0.5 flex items-center justify-between text-sm opacity-85">
                  {d.sub}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto mt-20 grid max-w-6xl gap-10 px-5 md:grid-cols-[1fr_1.1fr] md:px-6">
        <div>
          <SectionHead eyebrow="When hunger hits" title="Tonight's table">
            A taste of what's on property. Full list, hours and menus on the dining page.
          </SectionHead>
          <ul className="divide-y divide-border border-y border-border">
            {VENUES.slice(0, 4).map((v) => (
              <li key={v.id} className="flex items-center justify-between gap-4 py-4" data-testid={`row-venue-${v.id}`}>
                <div>
                  <p className="font-display text-xl">{v.name}</p>
                  <p className="text-sm text-muted-foreground">{v.kicker}</p>
                </div>
                <Ext href={v.menu} variant="outline" className="py-1.5 text-xs" testId={`link-menu-${v.id}`}>
                  Menu
                </Ext>
              </li>
            ))}
          </ul>
          <Link href="/dining" className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-primary" data-testid="link-all-dining">
            All dining <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="rounded-[2rem] bg-accent p-6 text-accent-foreground md:p-8">
          <p className="eyebrow text-[hsl(42_80%_70%)]">Front desk essentials</p>
          <h3 className="font-display mt-2 text-3xl">Need a hand?</h3>
          <ul className="mt-6 space-y-1">
            {GUEST_INFO.map((g) => (
              <li key={g.label}>
                <a href={g.href} className="flex items-center justify-between rounded-2xl px-3 py-3 transition-colors hover:bg-white/10" data-testid={`link-info-${g.label}`}>
                  <span className="opacity-85">{g.label}</span>
                  <span className="font-mono text-sm">{g.value}</span>
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-6 space-y-3 border-t border-white/15 pt-5 text-sm">
            <p className="flex gap-2"><MapPin className="h-4 w-4 shrink-0 text-[hsl(42_80%_70%)]" /> {RESORT.address}</p>
            <p className="flex gap-2"><Clock className="h-4 w-4 shrink-0 text-[hsl(42_80%_70%)]" /> Fitness center open 24 hours</p>
          </div>
          <div className="mt-6 flex flex-wrap gap-2">
            <Ext href={directionsUrl(`${RESORT.name}, ${RESORT.address}`)} variant="solid" testId="link-directions-resort">Directions</Ext>
            <Ext href={OFFICIAL.faq} variant="outline" className="border-white/30 hover:bg-white/10" testId="link-faq">Resort FAQs</Ext>
          </div>
        </div>
      </section>

      <section className="mx-auto mt-16 max-w-6xl px-5 md:px-6">
        <SubjectNote />
      </section>
    </>
  );
}
