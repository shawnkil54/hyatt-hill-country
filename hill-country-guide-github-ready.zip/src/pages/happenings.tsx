import { useState } from "react";
import { Chips, Ext, PageHero, SectionHead, SubjectNote } from "@/components/bits";
import { OFFICIAL, OUTDOORS, WATER, img, type Activity } from "@/data/content";

const TABS = [
  { id: "all", label: "Everything" },
  { id: "water", label: "Water" },
  { id: "around", label: "Around the resort" },
] as const;

function Grid({ items }: { items: Activity[] }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((a, i) => (
        <article
          key={a.id}
          className="rise group rounded-[1.5rem] border border-card-border bg-card p-5 transition-transform hover:-translate-y-0.5"
          style={{ animationDelay: `${i * 0.04}s` }}
          data-testid={`card-activity-${a.id}`}
        >
          <span className="eyebrow rounded-full bg-secondary px-2.5 py-1 text-[9px]">{a.tag}</span>
          <h3 className="font-display mt-3 text-2xl">{a.name}</h3>
          <p className="mt-1.5 text-sm text-muted-foreground">{a.line}</p>
        </article>
      ))}
    </div>
  );
}

export default function Happenings() {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("all");
  return (
    <>
      <PageHero
        eyebrow="What's happening"
        title={<>Float, play, <em>repeat.</em></>}
        lede="A lazy river, a beach lagoon, trails, courts and evenings by the fire. These are general offerings; schedules shift, so check the official calendar or ask the concierge."
        image={img("water.jpg")}
        alt="Illustrative lazy river"
      />
      <div className="mx-auto max-w-6xl px-5 pt-10 md:px-6">
        <div className="rounded-[1.75rem] bg-[hsl(42_80%_55%/.2)] p-5 md:flex md:items-center md:justify-between md:p-6">
          <div>
            <p className="font-display text-2xl">Today's schedule lives with the resort</p>
            <p className="mt-1 text-sm text-foreground/75">We don't post day-by-day times here. Confirm with the concierge.</p>
          </div>
          <div className="mt-4 flex flex-wrap gap-2 md:mt-0">
            <Ext href={OFFICIAL.experiences} variant="solid" testId="link-experiences">Current activities</Ext>
            <Ext href={OFFICIAL.activities} variant="outline" testId="link-official-activities">Events & attractions</Ext>
          </div>
        </div>

        <div className="mt-10 mb-6">
          <Chips options={TABS} value={tab} onChange={(value: (typeof TABS)[number]["id"]) => setTab(value)} testPrefix="filter-happenings" />
        </div>

        {(tab === "all" || tab === "water") && (
          <section className="mb-12" key={`w-${tab}`}>
            <SectionHead eyebrow="Water park & lagoon" title={<>Into the <em>blue</em></>} />
            <Grid items={WATER} />
          </section>
        )}
        {(tab === "all" || tab === "around") && (
          <section key={`a-${tab}`}>
            <SectionHead eyebrow="Around the resort" title={<>Under the <em>big sky</em></>} />
            <Grid items={OUTDOORS} />
          </section>
        )}
        <div className="mt-10"><SubjectNote /></div>
      </div>
    </>
  );
}
