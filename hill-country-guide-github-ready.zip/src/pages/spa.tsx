import { useState } from "react";
import { Leaf } from "lucide-react";
import { Call, Ext, PageHero, SectionHead, SubjectNote } from "@/components/bits";
import { cn } from "@/lib/utils";
import { OFFICIAL, SPA, img } from "@/data/content";

export default function Spa() {
  const [open, setOpen] = useState(0);
  return (
    <>
      <PageHero
        eyebrow="Windflower Spa"
        title={<>Slow <em>right down.</em></>}
        lede="Massages, facials, body treatments and nails inspired by native Hill Country ingredients. Open daily 8:30 am – 6 pm."
        image={img("spa.jpg")}
        alt="Illustrative spa still life"
      />
      <div className="mx-auto max-w-6xl px-5 pt-10 md:px-6">
        <div className="flex flex-wrap gap-2">
          <Ext href={SPA.book} variant="solid" testId="link-spa-book">Book a treatment</Ext>
          <Ext href={SPA.massageMenu} variant="teal" testId="link-spa-massage-menu">Massage menu</Ext>
          <Call number={SPA.phone} />
        </div>

        <div className="mt-14 grid gap-10 md:grid-cols-[1.2fr_1fr]">
          <div>
            <SectionHead eyebrow="Massage" title="Three ways in">
              Durations and pricing are on the official menu.
            </SectionHead>
            <div className="space-y-3">
              {SPA.massages.map((m, i) => (
                <button
                  key={m.name}
                  onClick={() => setOpen(i)}
                  data-testid={`button-massage-${m.name.toLowerCase()}`}
                  className={cn(
                    "w-full rounded-[1.5rem] border p-5 text-left transition-all",
                    open === i ? "border-[hsl(330_30%_55%/.5)] bg-[hsl(330_35%_92%)]" : "border-border bg-card hover:bg-card/70",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <p className="font-display text-2xl">{m.name}</p>
                    <span className="font-mono text-xs text-muted-foreground">0{i + 1}</span>
                  </div>
                  <div className={cn("grid transition-all duration-300", open === i ? "grid-rows-[1fr] opacity-100 mt-2" : "grid-rows-[0fr] opacity-0")}>
                    <p className="overflow-hidden text-sm text-foreground/75">{m.line}</p>
                  </div>
                </button>
              ))}
            </div>

            <div className="mt-6 rounded-[1.75rem] bg-accent p-6 text-accent-foreground">
              <p className="eyebrow text-[hsl(42_80%_70%)]">For two</p>
              <h3 className="font-display mt-1 text-3xl">Duet Massage</h3>
              <p className="mt-2 text-sm opacity-85">
                An 80-minute side-by-side massage. Priced per guest; two appointments required.
              </p>
              <Ext href={SPA.duet} variant="solid" className="mt-4" testId="link-spa-duet">See Duet details</Ext>
            </div>
          </div>

          <div className="rounded-[1.75rem] border border-border bg-card p-6 md:p-8 h-fit">
            <p className="eyebrow text-primary">Linger longer</p>
            <h3 className="font-display mt-2 text-3xl">Spa amenities</h3>
            <ul className="mt-5 space-y-3">
              {SPA.amenities.map((a) => (
                <li key={a} className="flex items-center gap-3">
                  <Leaf className="h-4 w-4 text-[hsl(95_30%_40%)]" />
                  {a}
                </li>
              ))}
            </ul>
            <p className="mt-6 text-sm text-muted-foreground">Availability, access and policies are on the official spa page.</p>
            <Ext href={OFFICIAL.spa} variant="outline" className="mt-3" testId="link-official-spa">Official spa page</Ext>
          </div>
        </div>
        <div className="mt-10"><SubjectNote /></div>
      </div>
    </>
  );
}
