import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent } from "react";
import { Link } from "wouter";
import { AlertTriangle, ArrowRight, Expand, Minus, Navigation, Plus, RotateCcw, X } from "lucide-react";
import { Chips, Ext, SectionHead, SubjectNote } from "@/components/bits";
import { cn } from "@/lib/utils";
import { HOTSPOTS, MAP_GROUPS, RESORT, VENUES, directionsUrl, embedUrl, img, type Hotspot, type MapGroup } from "@/data/content";

const GROUP_HUE: Record<MapGroup, string> = {
  dining: "bg-primary",
  recreation: "bg-[hsl(186_45%_38%)]",
  golf: "bg-[hsl(95_30%_36%)]",
  wellness: "bg-[hsl(330_32%_48%)]",
  essentials: "bg-foreground",
};

const MIN = 1;
const MAX = 4;
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

function ZoomMap({
  spots,
  selectedId,
  onSelect,
  tall,
}: {
  spots: Hotspot[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  tall?: boolean;
}) {
  const box = useRef<HTMLDivElement>(null);
  const [t, setT] = useState({ s: 1, x: 0, y: 0 });
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const last = useRef<{ dist: number; cx: number; cy: number } | null>(null);
  const moved = useRef(0);

  const bound = useCallback((s: number, x: number, y: number) => {
    const el = box.current;
    if (!el) return { s, x, y };
    const w = el.clientWidth;
    const h = el.clientHeight;
    return { s, x: clamp(x, w - w * s, 0), y: clamp(y, h - h * s, 0) };
  }, []);

  const zoomAt = useCallback(
    (factor: number, cx?: number, cy?: number) => {
      setT((p) => {
        const el = box.current;
        const px = cx ?? (el ? el.clientWidth / 2 : 0);
        const py = cy ?? (el ? el.clientHeight / 2 : 0);
        const s = clamp(p.s * factor, MIN, MAX);
        const k = s / p.s;
        return bound(s, px - (px - p.x) * k, py - (py - p.y) * k);
      });
    },
    [bound],
  );

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey && t.s === 1 && e.deltaY > 0) return;
      e.preventDefault();
      const r = el.getBoundingClientRect();
      zoomAt(e.deltaY < 0 ? 1.15 : 1 / 1.15, e.clientX - r.left, e.clientY - r.top);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [zoomAt, t.s]);

  // center on selection when zoomed
  useEffect(() => {
    const sp = HOTSPOTS.find((h) => h.id === selectedId);
    const el = box.current;
    if (!sp || !el) return;
    setT((p) => {
      const s = Math.max(p.s, 2);
      const w = el.clientWidth;
      const h = el.clientHeight;
      return bound(s, w / 2 - (sp.x / 100) * w * s, h / 2 - (sp.y / 100) * h * s);
    });
  }, [selectedId, bound]);

  const down = (e: RPointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    last.current = null;
    moved.current = 0;
  };
  const move = (e: RPointerEvent) => {
    const prev = pointers.current.get(e.pointerId);
    if (!prev) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const pts = [...pointers.current.values()];
    const r = box.current!.getBoundingClientRect();
    if (pts.length === 2) {
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      const cx = (pts[0].x + pts[1].x) / 2 - r.left;
      const cy = (pts[0].y + pts[1].y) / 2 - r.top;
      if (last.current) {
        const f = dist / last.current.dist;
        const dx = cx - last.current.cx;
        const dy = cy - last.current.cy;
        setT((p) => {
          const s = clamp(p.s * f, MIN, MAX);
          const k = s / p.s;
          return bound(s, cx - (cx - p.x) * k + dx, cy - (cy - p.y) * k + dy);
        });
      }
      last.current = { dist, cx, cy };
      moved.current += 10;
    } else {
      const dx = e.clientX - prev.x;
      const dy = e.clientY - prev.y;
      moved.current += Math.abs(dx) + Math.abs(dy);
      setT((p) => bound(p.s, p.x + dx, p.y + dy));
    }
  };
  const up = (e: RPointerEvent) => {
    pointers.current.delete(e.pointerId);
    last.current = null;
  };

  return (
    <div className="relative">
      <div
        ref={box}
        className={cn(
          "relative w-full overflow-hidden rounded-[1.5rem] border border-border bg-[hsl(40_30%_97%)] select-none",
          t.s > 1 ? "cursor-grab active:cursor-grabbing" : "",
          tall ? "aspect-[1159/897] max-h-[78dvh]" : "aspect-[1159/897]",
        )}
        style={{ touchAction: t.s > 1 ? "none" : "pan-y" }}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
        data-testid="map-canvas"
      >
        <div
          className="absolute inset-0 origin-top-left transition-transform duration-150 ease-out will-change-transform"
          style={{ transform: `translate(${t.x}px, ${t.y}px) scale(${t.s})` }}
        >
          <img
            src={img("property-map.jpg")}
            alt="Resort property map as provided, showing dining, pools, lagoon, golf club and spa"
            className="pointer-events-none h-full w-full"
            draggable={false}
          />
          {spots.map((h) => {
            const active = h.id === selectedId;
            return (
              <button
                key={h.id}
                onClick={() => moved.current < 8 && onSelect(h.id)}
                onPointerDown={(e) => { moved.current = 0; e.stopPropagation(); }}
                aria-label={`${h.name}${h.num ? `, map number ${h.num}` : ""}`}
                aria-pressed={active}
                data-testid={`hotspot-${h.id}`}
                className="group absolute -translate-x-1/2 -translate-y-1/2 p-2 focus:outline-none"
                style={{ left: `${h.x}%`, top: `${h.y}%`, transform: `translate(-50%,-50%) scale(${1 / t.s})` }}
              >
                {active && <span className="absolute inset-0 m-auto h-9 w-9 animate-ping rounded-full bg-primary/40" />}
                <span
                  className={cn(
                    "relative grid h-7 w-7 place-items-center rounded-full border-2 border-white text-[11px] font-semibold text-white shadow-md transition-transform group-hover:scale-110 group-focus-visible:ring-4 group-focus-visible:ring-ring/60",
                    GROUP_HUE[h.group],
                    active && "scale-125",
                  )}
                >
                  {h.num ?? "•"}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <div className="absolute right-3 top-3 flex flex-col overflow-hidden rounded-2xl border border-border bg-card/95 shadow-md backdrop-blur">
        <button aria-label="Zoom in" onClick={() => zoomAt(1.4)} className="grid h-10 w-10 place-items-center hover:bg-muted" data-testid="button-zoom-in"><Plus className="h-4 w-4" /></button>
        <button aria-label="Zoom out" onClick={() => zoomAt(1 / 1.4)} className="grid h-10 w-10 place-items-center border-t border-border hover:bg-muted" data-testid="button-zoom-out"><Minus className="h-4 w-4" /></button>
        <button aria-label="Reset zoom" onClick={() => setT({ s: 1, x: 0, y: 0 })} className="grid h-10 w-10 place-items-center border-t border-border hover:bg-muted" data-testid="button-zoom-reset"><RotateCcw className="h-4 w-4" /></button>
      </div>
      <span className="pointer-events-none absolute bottom-3 left-3 rounded-full bg-card/90 px-2.5 py-1 font-mono text-[10px] text-muted-foreground">
        {Math.round(t.s * 100)}%
      </span>
    </div>
  );
}

function Detail({ spot, onClose }: { spot: Hotspot; onClose?: () => void }) {
  const venue = VENUES.find((v) => v.id === spot.venueId);
  return (
    <div className="rise rounded-[1.5rem] border border-card-border bg-card p-5" data-testid="panel-place-detail">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="eyebrow text-primary">{spot.num ? `Map no. ${spot.num}` : "On the map"}</p>
          <h3 className="font-display mt-1 text-2xl" data-testid="text-selected-place">{spot.name}</h3>
          {spot.mapLabel && (
            <p className="mt-1 text-xs text-muted-foreground">Labeled “{spot.mapLabel}” on the printed map; current name shown above.</p>
          )}
        </div>
        {onClose && (
          <button onClick={onClose} aria-label="Clear selection" className="rounded-full p-1.5 hover:bg-muted" data-testid="button-clear-place"><X className="h-4 w-4" /></button>
        )}
      </div>
      <p className="mt-2 text-sm text-foreground/80">{spot.detail}</p>
      {venue && (
        <dl className="mt-3 space-y-1 text-sm">
          {venue.hours.map((h) => (
            <div key={h.label} className="flex justify-between gap-3"><dt className="text-muted-foreground">{h.label}</dt><dd className="font-mono text-[12px]">{h.value}</dd></div>
          ))}
        </dl>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        {venue && <Ext href={venue.menu} variant="solid" testId={`link-map-menu-${spot.id}`}>{venue.id === "aunt-dis" ? "Aunt Di's menu" : "Menu"}</Ext>}
        <Link href={spot.guide.href} className="inline-flex items-center gap-1.5 rounded-full border border-foreground/20 px-4 py-2.5 text-sm font-medium hover:bg-muted" data-testid={`link-map-guide-${spot.id}`}>
          {spot.guide.label} <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}

export default function MapPage() {
  const [group, setGroup] = useState<"all" | MapGroup>("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [full, setFull] = useState(false);
  const groups = useMemo(() => MAP_GROUPS.filter((g) => g.id === "all" || HOTSPOTS.some((h) => h.group === g.id)), []);
  const list = useMemo(() => (group === "all" ? HOTSPOTS : HOTSPOTS.filter((p) => p.group === group)), [group]);
  const selected = HOTSPOTS.find((h) => h.id === selectedId) ?? null;
  const resortQ = `${RESORT.name}, ${RESORT.address}`;

  useEffect(() => {
    if (!full) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setFull(false);
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", k);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", k);
    };
  }, [full]);

  const warning = (
    <p className="flex items-center gap-2 rounded-xl bg-[hsl(42_80%_55%/.2)] px-3 py-2 text-xs font-medium" data-testid="text-golf-warning">
      <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-primary" />
      Golf course is not open for pedestrian and bike traffic.
    </p>
  );

  return (
    <div className="mx-auto max-w-6xl px-5 pt-24 md:px-6">
      <SectionHead eyebrow="Property map" title={<>Where to, <em>partner?</em></>}>
        Tap a numbered pin or pick from the list. Pinch, drag or use the buttons to zoom. For routes between buildings, ask the front desk.
      </SectionHead>

      <div className="mb-4">
        <Chips options={groups} value={group} onChange={(value: "all" | MapGroup) => setGroup(value)} testPrefix="filter-map" />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-3">
          <ZoomMap spots={list} selectedId={selectedId} onSelect={setSelectedId} />
          <div className="flex flex-wrap items-center justify-between gap-2">
            {warning}
            <button onClick={() => setFull(true)} className="inline-flex items-center gap-1.5 rounded-full border border-foreground/20 px-4 py-2 text-sm hover:bg-card" data-testid="button-map-fullscreen">
              <Expand className="h-4 w-4" /> Expand map
            </button>
          </div>
          <p className="text-xs text-muted-foreground">
            Map as provided by the resort; some printed labels may differ from current venue names.
          </p>
        </div>

        <div className="space-y-3">
          {selected ? (
            <Detail spot={selected} onClose={() => setSelectedId(null)} />
          ) : (
            <div className="rounded-[1.5rem] border border-dashed border-foreground/25 p-5 text-sm text-muted-foreground">
              Select a pin to see hours, menus and the right guide page.
            </div>
          )}
          <ul className="space-y-1.5" aria-label="Map locations">
            {list.map((h) => (
              <li key={h.id}>
                <button
                  onClick={() => setSelectedId(h.id)}
                  aria-pressed={h.id === selectedId}
                  data-testid={`button-place-${h.id}`}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-2xl border px-3 py-2.5 text-left text-sm transition-all active:scale-[.98]",
                    h.id === selectedId ? "border-accent bg-card" : "border-transparent bg-card/50 hover:bg-card",
                  )}
                >
                  <span className={cn("grid h-7 w-7 shrink-0 place-items-center rounded-full text-[11px] font-semibold text-white", GROUP_HUE[h.group])}>{h.num ?? "•"}</span>
                  <span className="flex-1 font-medium">{h.name}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-14 grid gap-5 md:grid-cols-[1.3fr_1fr]">
        <div className="overflow-hidden rounded-[1.5rem] border border-border">
          <iframe title="Resort location on Google Maps" src={embedUrl(resortQ)} className="h-[300px] w-full" loading="lazy" referrerPolicy="no-referrer-when-downgrade" data-testid="iframe-google-map" />
        </div>
        <div className="flex flex-col justify-between gap-4 rounded-[1.5rem] bg-secondary p-6">
          <div>
            <p className="eyebrow text-primary">Getting here</p>
            <p className="font-display mt-1 text-2xl">{RESORT.name}</p>
            <p className="mt-1 text-sm">{RESORT.address}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Ext href={directionsUrl(resortQ)} variant="solid" testId="link-directions"><Navigation className="h-4 w-4" /> Directions</Ext>
          </div>
          <SubjectNote />
        </div>
      </div>

      {full && (
        <div className="fixed inset-0 z-50 flex flex-col bg-background/97 p-3 backdrop-blur md:p-6" role="dialog" aria-modal="true" aria-label="Expanded property map">
          <div className="mb-3 flex items-center justify-between">
            <p className="font-display text-xl">Property map</p>
            <button onClick={() => setFull(false)} className="inline-flex items-center gap-1 rounded-full bg-foreground px-4 py-2 text-sm text-background" data-testid="button-map-close" autoFocus>
              <X className="h-4 w-4" /> Close
            </button>
          </div>
          <div className="mx-auto w-full max-w-[min(100%,calc(78dvh*1159/897))] flex-1">
            <ZoomMap spots={list} selectedId={selectedId} onSelect={setSelectedId} tall />
            <div className="mt-3">{warning}</div>
            {selected && <div className="mt-3 max-w-md"><Detail spot={selected} /></div>}
          </div>
        </div>
      )}
    </div>
  );
}
