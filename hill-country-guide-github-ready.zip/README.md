# Hill Country Guest Guide — source code

Complete editable React + TypeScript + Vite web app, including the supplied
interactive resort map, images, dining links, golf, spa, activities and QR sharing.
No backend, database, API keys, or Replit hosting is required.

## Run locally

Install Node.js 22.12 or newer. In this folder run:

    npm install
    npm run dev

## Build

    npm run typecheck
    npm run build
    npm run preview

The finished website is written to `dist/`.

## Publish on GitHub Pages

1. Create a public GitHub repository and upload this folder's contents.
2. In the repository choose Settings → Pages → Source → GitHub Actions.
3. The included workflow builds and publishes the site after a push to main.
   If needed, start it manually from Actions → Publish guest guide → Run workflow.
4. Open the live link shown in Pages settings. Use Share in the live guide to
   generate a QR code pointing to that site.

This export uses hash navigation (`#/map`) to avoid page-refresh errors on
GitHub Pages. Images use relative paths, so any repository name is supported.

## Editing

- Resort details, restaurant links and map hotspots: `src/data/content.ts`
- Individual screens: `src/pages/`
- Shared navigation and QR sharing: `src/components/shell.tsx`
- Styling: `src/index.css`
- Images and supplied property map: `public/img/`

This is an independent guest guide, not Hyatt's official website.
Verify current operating hours and activities with the resort before sharing.
Illustrative images are labeled in the app.
