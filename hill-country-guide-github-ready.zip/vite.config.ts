import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

const root = path.dirname(fileURLToPath(import.meta.url));
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss()],
  define: { 'import.meta.env.VITE_GITHUB_PAGES': JSON.stringify('true') },
  resolve: { alias: { '@': path.join(root, 'src') } },
});
